/*
Clase principal que implementa los métodos de la clase SymbolTable
 */
package Lector;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Scanner;
import Estructuras.*;
import java.util.InputMismatchException;

/**
 *
 * @author Nicolás Rincón
 * @author Andrés Quintero
 * @author Ailen Moreno
 * 
 * @since 2022/11/22
 * @version 1.0
 */

public class Main {
    public static String[] retirarCaracteres(String texto) throws FileNotFoundException, IOException{
        String cadena = "";
        String cadena2 = "";
        
        FileReader c = new FileReader(texto);
        BufferedReader d = new BufferedReader(c);
        while((cadena = d.readLine()) != null){
            cadena2+= cadena.replaceAll("[!¡\"#$%&'()*+,-.«»/:;<=>?¿@1234567890\\[\\]^_`{|}~]", "") + " ";
        }
        String[]ListaPalabras = cadena2.split(" ");
        d.close();
        return ListaPalabras;
    }
    

    
    public static void main(String[] args) throws FileNotFoundException,IOException {
        Scanner in = new Scanner(System.in);
        String[] lista;
        lista = retirarCaracteres("C:\\Users\\Polut\\OneDrive\\Documentos\\fifa.txt");
        int minTamaño= 1; 
        SymbolTable<String, Integer> st = new SymbolTable<>(lista.length);
        
        for (int i = 0; i < lista.length; i++) {
            String word = lista[i].toLowerCase();
            if(word.length() > minTamaño){
                
            
                if (!st.contains(word)) {
                    st.put(word, 1);
                } else {
                    st.put(word, st.get(word) + 1);
                }
            }
        }
        while(true){
            try{
            String llave;
            int valor;
            System.out.println("*****OPCIONES BIBLIA*****\n"
                            + "1.Numero de palabras del texto\n"
                            + "2.Imprimir todas las palabras con el numero de veces repetidas\n"
                            + "3.Imprimir palabras que empiezen por la letra dada\n"
                            + "4.Buscar palabra y las veces que se repite\n"
                            + "5.Numero de palabras sin tener en cuenta repetidos");
            System.out.println("*****OPCION TABLA DE SIMBOLOS****\n"
                            + "6.Ingresar\n"
                            + "7.Obtener\n"
                            + "8.¿La llave esta en la tabla?\n"
                            + "9.Minimo\n"
                            + "10.Maximo\n"
                            + "11.Piso de una llave dada\n"
                            + "12.Techo de una llave dada\n"
                            + "13.Select\n"
                            + "14.Rango\n"
                            + "15.Size de un tamaño\n"
                            + "16.Salir\n");
            int opcion = in.nextInt();
                switch (opcion) {
                    case 1: 
                        System.out.println("la Cantidad de palabras " + lista.length);
                        break;
                    
                    case 2: 
                        for(String palabra : st.keys()){
                            if(palabra !=null){
                            System.out.println(palabra + ":" + st.get(palabra));
                            }
                        }
                        break;
                    case 3:
                        System.out.println("Ingrese la letra");
                        String letra = in.next();
                        for(String palabra : st.keys()){
                            if(palabra!=null){
                                if(palabra.startsWith(letra.toLowerCase())){
                                    System.out.println(palabra + ":" + st.get(palabra));
                                }
                            }
                                
                        }
                    case 4:
                        System.out.println("Ingrese la palabra a buscar");
                        String palabra = in.next();
                        if(st.get(palabra.toLowerCase()) !=null){
                            System.out.println(palabra + ":" + st.get(palabra.toLowerCase()));
                        }
                        else{
                            System.out.println("La palabra no esta en el texto");
                        }
                        break;
                    case 5:
                        System.out.println(st.size());
                        break;
                    case 6:
                        System.out.println("Ingrese la llave");
                        llave = in.next();
                        System.out.println("Ingrese el valor de esa llave");
                        valor = in.nextInt();
                        st.put(llave, valor);
                        break;
                    case 7:
                        System.out.println("Ingrese la llave a buscar");
                        llave = in.next();
                        System.out.print("El valor de la llave es: " + st.get(llave));
                        break;
                    case 8:
                        System.out.println("Ingrese la llave a buscar");
                        llave = in.next();
                        if(st.contains(llave) == true){
                            System.out.println("La llave esta en la tabla de simbolos");
                        }
                        else{
                            System.out.println("La llave no esta en la tabla de simbolos");
                        }
                        break;
                    case 9:
                        System.out.println("La palabra minima es: " + st.min());
                        break;
                    case 10: 
                        System.out.println("La palabra maxima es: " + st.max());
                        break;
                    case 11:
                        System.out.println("Ingrese la llave");
                        llave = in.next();
                        System.out.println("El piso de la llave es: " + st.floor(llave));
                        break;
                    case 12:
                        System.out.println("Ingrese la llave");
                        llave = in.next();
                        System.out.println("El techo de la llave es: " + st.ceiling(llave));
                        break;
                    case 13:
                        System.out.println("Ingrese el indice");
                        int k = in.nextInt();
                        System.out.println("La llave es:" + st.select(k));
                        break;
                    case 14:
                        System.out.println("Ingrese la llave de la cual quiere el rango");
                        llave = in.next();
                        System.out.println("El rango es: " + st.rank(llave));
                        break;
                    case 15:
                        System.out.println("Ingrese las llaves de las cuales quiere el rango");
                        System.out.println("Llave 1");
                        llave = in.next();
                        System.out.println("LLave 2");
                        String llave2 = in.next();
                        System.out.println("El rango es: " + st.size(llave, llave2));
                        break;
                    case 16:
                        System.exit(0);
                }
            }
            catch (InputMismatchException inputMismatchException) {
                System.err.printf("Excepción inputMismatchException\n", inputMismatchException);
                System.out.println("Error. Tipo de dato no permitido");
                in.nextLine();
            } 
            catch (NumberFormatException numberFormatException) {
                System.err.printf("\nExcepción numberFormatException\n", numberFormatException);
                System.out.println("Error al introducir dato");
                in.nextLine();
            } 
            catch (NullPointerException nullPointerException) {
                System.err.printf("\nExcepción nullPointerException\n", nullPointerException);
                System.out.println("Error al introducir dato");
                in.nextLine();
            }
        }
    }
}
