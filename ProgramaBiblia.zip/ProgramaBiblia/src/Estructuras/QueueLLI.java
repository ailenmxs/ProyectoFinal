/*
 * Estructura de datos cola (FIFO) implementada con nodos enlazados
 * Esta estructura de datos permite almacenar cualquier cantidad de datos
 * de tipo genérico
 */
package Estructuras;

import java.util.Iterator;

/**
 *
 * @author Nicolás Rincón
 * @author Andrés Quintero
 * @author Ailen Moreno
 * 
 * @since 2022/11/22
 * @version 1.0
 */
public class QueueLLI <Item> implements Iterable <Item> {
    
    private int count;
    private Node first;
    private Node last;
    
    /**
     * Constructor sin parametros
     */
    public QueueLLI (){
        first = null;
        count=0;
        last = null;
    }

   /**
    * Clase anidada que define la estructura de un nodo
    */
    private class Node{
        Item item;
        Node next;
    }
    /**
     * El metodo enqueue inserta un elemento en la cola
     * @param item Recibe el elemento a insertar 
     */
    public void enqueue(Item item){
        Node oldLast = last;
        last = new Node();
        last.item= item;
        last.next=null;
        if(count > 0)
            oldLast.next = last;
        else
            first = last;
        count++;
    }
    /**
     * El metodo dequeue retira el primer elemento de la cola
     * @return Retira y retorna el primer elemento de la cola
     **/
    public Item dequeue(){
        Item item = first.item;
        first.item=null;
        first = first.next;
        count--;
        if(isEmpty())
            last = null;
        return item;
        
    }
    
    public void clear(){
        while(count >= 0){
        Item item = first.item;
        first.item=null;
        first.next=null;
         
          if(isEmpty())
            last = null;
        count++;
        }
    }
    
    /**
     * 
     * @return Retorna true si la cola esta vacia o false en caso contario
     */
    public boolean isEmpty(){
        return first == null; // return count==0;
    }
    
    /**
     * 
     * @return Retorna la cantidad de datos almacenados en la cola 
     */
    public int size(){
        return count;
    }
    
     @Override
    public Iterator<Item> iterator() {
        return new LLIterator();
    }
    private class LLIterator implements Iterator <Item>{
        
        private Node current = first;

        @Override
        public boolean hasNext() {
            return current != null;    
        }

        @Override
        public Item next() {
            Item item = current.item;
            current = current.next;
            return item;   
        }
    }    
}
