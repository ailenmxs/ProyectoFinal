/*
 * Estructura de datos tabla de símbolos ST
 * Esta estructura de datos permite almacenar pares clave/valor
 * de tipo genérico
 */

package Estructuras;

/**
 *
 * @author Nicolás Rincón
 * @author Andrés Quintero
 * @author Ailen Moreno
 * 
 * @since 2022/11/22
 * @version 1.0
 */

public class SymbolTable<Key extends Comparable <Key>, Value> {
    private Key[]keys;
    private Value[]vals;
    private int N;
    
    
    /**
     * Constructor
     * @param capacity Recibe el tamaño del arreglo que lo da la cantidad de
     *                 palabras (claves)
     */
    public SymbolTable(int capacity){
        keys = (Key[]) new Comparable[capacity];
        vals = (Value[]) new Object[capacity];
    }
    
     /**
     * El método put permite ingresar una llave con un valor a la tabla
     * @param key Recibe la clave
     * @param val Recibe el valor asociado a esa clave
     */
    public void put(Key key, Value val){
        int i = rank(key);
        if (i < N && keys[i].compareTo(key) == 0) {
            vals[i] = val;
            return;
        }
        for (int j = N; j > i; j--) {
            keys[j] = keys[j - 1];
            vals[j] = vals[j - 1];
        }
        keys[i] = key;
        vals[i] = val;
        N++;
    }
    
     /**
     * El método get recibe una clave y devuelve el valor de esa clave
     * @param key Recibe la clave
     */
    public Value get(Key key){
        if(isEmpty()){
            return null;
        }
        int i = rank(key);
        if (i < N && keys[i].compareTo(key) == 0) {
            return vals[i];
        }
        else{
            return null;
        }
    }
    
    
     /**
     * El método contains recibe una clave a buscar y devuelve true si
     * la encuentra, sino retorna false
     * @param key Recibe la clave
     */    
    public boolean contains(Key key){
        int lo = 0, hi = N - 1;
        while(lo <= hi){
            int mid = lo + (hi - lo) / 2;
            int cmp = key.compareTo(keys[mid]);
            if(cmp < 0){
                hi = mid - 1;
            }
            else if(cmp > 0){
                lo = mid + 1;
            }
            else{
                return true;
            }
        }
        return false;
    }

     /**
     * El método select recibe una clave y devuelve la posición donde se encuentra
     * @param k Recibe la clave
     */    
    public Key select(int k) {
        return keys[k];
    }
    
     /**
     * El método isEmpty verifica si la tabla de simbolos está vacía
     *@return Retorna true si la tabla está vacía, false en caso contrario
     */
    public boolean isEmpty(){
        return N==0;
    }

     /**
     * El método size muestra la cantidad de claves que hay en la estructura
     * @return Retorna el tamaño de la estructura
     */
    public int size(){
        return N;
    }
    
     /**
     * El método min muestra la clave menor de la tabla de símbolos
     * @return Retorna la posición 0 del arreglo donde se encuentra la clave menor
     */ 
    public Key min(){
        return keys[0];
    }
     /**
     * El método max muestra la clave mayor de la tabla de símbolos
     * @return Retorna la última posición del arreglo donde se encuentra la clave mayor
     */     
    public Key max(){
        return keys[N-1];
    }
    
     /**
     * El método floor recibe una clave para ver la clave anterior a esta (piso)
     * @param key Recibe la clave
     * @return Retorna la clave
     */ 
    public Key floor(Key key){
        int i = rank(key);
        return keys[i-1];
    }
    
     /**
     * El método ceiling recibe una clave para ver la clave siguiente a esta(techo)
     * @param key Recibe la clave
     * @return Retorna la clave
     */ 
    public Key ceiling(Key key){
        int i = rank(key);
        return keys[i+1];
    }
    
     /**
     * El método rank recibe una clave y muestra el número de claves que están
     * antes de esa clave
     * @param key Recibe la clave
     * @return Retorna el número de claves anteriores
     */  
    public int rank(Key key){
        int lo = 0,hi = N-1;
        while(lo <= hi){
            int mid = lo + (hi - lo) / 2;
            int cmp = key.compareTo(keys[mid]);
            if(cmp < 0){
                hi = mid - 1;
            }
            else if(cmp > 0){
                lo = mid + 1;
            }
            else{ 
            return mid;
            }
        }
        return lo;
    }
    
     /**
     * El método DeleteMin elimina la clave menor
     */ 
    public void DeleteMin(){
        
    }

     /**
     * El método DeleteMax elimina la clave mayor
     */ 
    public void DeleteMax(){
        
    }

     /**
     * El método size indica el tamaño que hay entre dos claves
     * @param lo Recibe la clave menor
     * @param hi Recibe la clave mayor
     * @return Retorna el tamaño que hay entre dos claves
     */ 
    public int size(Key lo, Key hi){
        if(hi.compareTo(lo) < 0)
            return 0;
        else if(contains(hi))
            return rank(hi) - rank(lo) + 1;
        else 
            return rank(hi) - rank(lo);
    }

    public Iterable<Key> keys(Key lo, Key hi){
        QueueLLI<Key> q = new QueueLLI<>();
        for (int i = rank(lo); i < rank(hi); i++) {
            q.enqueue(keys[i]);
        }
        if(contains(hi)){
            q.enqueue(keys[rank(hi)]);
        }
        return q;
    }

    public Iterable<Key> keys(){
        QueueLLI<Key> q = new QueueLLI<>();
        for (int i = 0; i < keys.length; i++) {
            q.enqueue(keys[i]);
        }
        return q;
    }
        
}
